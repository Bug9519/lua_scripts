-- Example 26 - Functions.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

-- Define a function without parameters or return value.
function myFirstLuaFunction()
	print("My first lua function was called")
end

-- Call myFirstLuaFunction.
myFirstLuaFunction()
