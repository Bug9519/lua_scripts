-- Example 3 - Variables
-- Variables hold values which have types, variables don't have types.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a=1
b="abc"
c={}
d=print

print(type(a))
print(type(b))
print(type(c))
print(type(d))
