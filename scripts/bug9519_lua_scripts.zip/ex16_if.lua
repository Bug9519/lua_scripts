-- Example 16 - if statement
-- Simple if.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a=1
if a==1 then
	print("a is one")
end
