-- Example 12 - More Output.
-- More writing output.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

print "Hello from Lua!"
print("Hello from Lua!")
