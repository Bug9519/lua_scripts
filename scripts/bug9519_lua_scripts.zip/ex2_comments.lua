-- Example 2 -- Comments
-- Single line comments in Lua start with double hyphen.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

--[[ Multiple line comments start
with double hyphen and two square brackets.
  and end with two square brackets. ]]

-- And of course this example produces no
-- output, since it's all comments!

