-- Example 14 - Tables
-- Simple table creation.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a={} -- {} creates an empty table.
b={1,2,3} -- creates a table containing numbers 1,2,3
c={"a","b","c"} -- creates a table containing strings a,b,c

print(a,b,c) -- tables don't print directly, we'll get back to this!!
