-- Example 17 - if else statement.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

b="happy"
if b=="sad" then
	print("b is sad")
else
	print("b is not sad")
end
