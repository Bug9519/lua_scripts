-- Example 24 - Printing tables.
-- Simple way to print tables.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a={1,2,3,4,"five","elephant", "mouse"}

for i,v in pairs(a) do print(i,v) end
