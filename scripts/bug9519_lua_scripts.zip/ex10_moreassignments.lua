-- Example 10 - More Assignments
-- Multiple assignments allows one line to swap two variables.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

print(a,b)
a,b=b,a
print(a,b)
