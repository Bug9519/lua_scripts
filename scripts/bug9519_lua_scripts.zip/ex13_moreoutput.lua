-- Example 13 - More Output
-- io.write writes to stdout but without new line.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

io.write("Hello from Lua!")
io.write("Hello from Lua!")

-- Use an empty print to write a single new line.
print()
