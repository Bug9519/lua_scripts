-- Example 27 - More Functions.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

-- Define a function with a return value.
function mySecondLuaFaction()
	return "string from my second function"
end

-- Call function returning a value.
a=mySecondLuaFaction("string")
print(a)
