-- Example 4 - Variable Names
-- Variable names consist of letters, digits and underscores.
-- They cannot start with a digit.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

one_two_3 = 123 -- is a valid variable name.
-- 1_two_3 is not a valid variable name.
