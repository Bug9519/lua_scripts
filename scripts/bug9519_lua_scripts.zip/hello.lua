--- Hello World program - lua
--- Coded by Bug9519
print("Hello, World! from Bug9519.")
