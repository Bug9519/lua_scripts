-- Example 20 - while statement
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a=1
while a~=5 do -- Lua uses ~= to mean not equal
	a=a+1
	io.write(a.." ")
end
