-- Example 33 - Standard Libraries - string.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

-- String functions:
-- string.byte, string.char, string.dump, string.find, string.format,
-- string.gfind, string.gsub, string.len, string.lower, string.match,
-- string.rep, string.reverse, string.sub, string.upper

print(string.upper("lower"),string.rep("a",5),string.find("abcde", "cd"))
