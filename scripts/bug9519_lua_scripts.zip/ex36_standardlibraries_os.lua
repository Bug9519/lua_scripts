-- Example 36 - Standard Libraries - Operating System facilities.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

-- OS functions:
-- os.clock, os.date, os.difftime, os.execute, os.exit, os.getenv,
-- os.remove, os.rename, os.setlocale, os.time, os.tmpname

print(os.date())
