-- Example 18 - if elseif else statement
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

c=3
if c==1 then
	print("c is 1")
elseif c==2 then
	print("c is 2")
else
	print("c isn't 1 or 2, c is "..tostring(c))
end
