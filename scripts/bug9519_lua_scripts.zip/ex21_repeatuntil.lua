-- Example 21 - repeat until statement.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a=0
repeat
	a=a+1
	print(a)
until a==5 -- This can basically be any number, and lua will go up to it.
