-- Example 23 - More for statement.
-- Sequential iteration form.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

for key,value in pairs({1,2,3,4}) do print(key, value) end
