-- Example 9 - Assignments
-- Multiple assignments are valid.
-- var1,var2=var3,var4
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a,b,c,d,e = 1, 2, "three", "four", 5

print(a,b,c,d,e)
