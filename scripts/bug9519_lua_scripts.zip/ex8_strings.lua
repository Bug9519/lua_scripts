-- Example 8 - Strings.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a="single 'quoted' string and double \"quoted\" string inside"
b='single \'quoted\' string and double "quoted" string inside'
c= [[ multiple line
with 'single'
and "double" quoted strings inside.]]

print(a)
print(b)
print(c)
