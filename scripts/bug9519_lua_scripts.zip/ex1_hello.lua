-- Example1 - "Hello" program - lua
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).
print("Hello!")
