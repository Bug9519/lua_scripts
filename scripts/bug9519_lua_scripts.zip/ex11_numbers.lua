-- Example 11 - Numbers
-- Multiple assignment showing different number formats.
-- Two dots (..) are used to concatenate strings (or a
-- string and a number).
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a,b,c,d,e = 1, 1.123, 1E9, -123, .0008
print("a="..a, "b="..b, "c="..c, "d="..d, "e="..e)
