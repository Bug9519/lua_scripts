-- Example 25 - break statement.
-- break is used to exit a loop.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

a=0
while true do
	a=a+1
	if a==10 then
		break
	end
end

print(a)
