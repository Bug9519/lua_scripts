-- Example 6 - Case Sensitive.
-- Lua is case sensitive so all variable names & keywords
-- must be in correct case
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

ab=1
Ab=2
AB=3
print(ab,Ab,AB)
