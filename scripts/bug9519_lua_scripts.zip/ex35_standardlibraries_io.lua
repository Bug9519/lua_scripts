-- Example 35 - Standard Libraries - input/output.
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

-- IO functions:
-- io.close, io.flush, io.input, io.lines, io.open, io.output, io.popen,
-- io.read, io.stderr, io.stdin, io.stdout, io.tmpfile, io.type, io.write,
-- file:close, file:flush, file:lines, file:read,
-- file:seek, file:setvbuf, file:write

	print(io.open("file doesn't exist", "r"))
