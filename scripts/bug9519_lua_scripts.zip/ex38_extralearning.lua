-- Example 38 - Extra Learning
-- Coded by Bug9519.
-- Coded on 5/04/2021 (5th of April, 2021).

--[[
To learn more about Lua scripting see

Lua Tutorials: http://lua-users.org/wiki/TutorialDirectory

"Programming in Lua" Book: http://www.inf.puc-rio.br/~roberto/pil2/

Lua 5.1 Reference Manual:
	Start/Programs/Lua/Documentation/Lua 5.1 Reference Manual

Examples: Start/Programs/Lua/Examples
]]
c= [[
To learn more about Lua scripting see

Lua Tutorials: http://lua-users.org/wiki/TutorialDirectory

"Programming in Lua" Book: http://www.inf.puc-rio.br/~roberto/pil2/

Lua 5.1 Reference Manual:
	Start/Programs/Lua/Documentation/Lua 5.1 Reference Manual

Examples: Start/Programs/Lua/Examples
]]

print(c)
